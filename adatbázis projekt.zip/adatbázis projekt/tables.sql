Table person {
  id int [pk, increment]
  name varchar
  age int
  height int
  hair_color varchar
  eye_color varchar
  is_traitor boolean
}

Table detective {
  id int [pk, increment]
  name varchar
  birth_year int
  experience_years int
}

Table interrogation {
  id int [pk, increment]
  person_id int [ref: > person.id]
  detective_id int [ref: > detective.id]
  date date
}

Table statement {
  id int [pk, increment]
  interrogation_id int [ref: > interrogation.id]
  statement_text text
}
